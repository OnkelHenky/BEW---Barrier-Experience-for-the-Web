function no_cursor_1(){
	chrome.tabs.executeScript(
	{
		file: 'js/operable/no_cursor_1.js'
	}); 
}

function no_cursor_2(){
	chrome.tabs.executeScript(
	{
		file: 'js/operable/no_cursor_2.js'
	}); 
}