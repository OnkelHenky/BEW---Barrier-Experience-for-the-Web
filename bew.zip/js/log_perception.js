/*function perception_screenreader(){
	chrome.tabs.executeScript(
	{
		file: 'js/perception/perception_screenreader.js'
	}); 
}*/

function perception_contrast_AA_luminance(){
	chrome.tabs.executeScript(
	{
		file: 'js/perception/perception_contrast_AA_luminance.js'
	}); 
}

function perception_contrast_AAA_luminance(){
chrome.tabs.executeScript(
	{
		file: 'js/perception/perception_contrast_AAA_luminance.js'
	}); 
}

function perception_contrast_AA_randomColor(){
	chrome.tabs.executeScript(
	{
		file: 'js/perception/perception_contrast_AA_randomColor.js'
	}); 
}

function perception_contrast_AAA_randomColor(){
chrome.tabs.executeScript(
	{
		file: 'js/perception/perception_contrast_AAA_randomColor.js'
	}); 
}