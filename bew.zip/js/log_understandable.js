function understandable_Akademiker(){
	chrome.tabs.executeScript(
	{
		file: 'js/understandable/understandable_Akademiker.js'
	}); 
}

function understandable_teenager(){
	chrome.tabs.executeScript(
	{
		file: 'js/understandable/understandable_teenager.js'
	}); 
}

function understandable_child(){
	chrome.tabs.executeScript(
	{
		file: 'js/understandable/understandable_child.js'
	}); 
}
