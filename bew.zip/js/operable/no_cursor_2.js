console.log("contentscript gets executed.");
alert("Place here your operable clarification");

